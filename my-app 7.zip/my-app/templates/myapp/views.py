from django.shortcuts import render, redirect
from .models import CustomUser
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.hashers import make_password

def login_view(request):
    return render(request, 'myapp/login.html')

def about_view(request):
    return render(request, 'myapp/about.html')

def register_view(request):
    if request.method == 'POST':
        email = request.POST['email']
        first = request.POST['first_name']
        last = request.POST['last_name']
        password = request.POST['password']
        confirm = request.POST['confirmpassword']
        image = request.FILES.get('image')

        if password != confirm:
            return render(request, 'myapp/register.html', {'error': 'Паролі не співпадають'})

        image_name = None
        if image:
            fs = FileSystemStorage()
            image_name = fs.save(image.name, image)

        CustomUser.objects.create(
            email=email,
            first_name=first,
            last_name=last,
            password=make_password(password),
            image=image_name
        )
        return redirect('login')

    return render(request, 'myapp/register.html')
