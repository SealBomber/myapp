from django.shortcuts import render, redirect
from .models import CustomUser
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.hashers import make_password

def login_view(request):
    return render(request, 'myapp/login.html')

def about_view(request):
    return render(request, 'myapp/about.html')

def register_view(request):
    if request.method == 'POST':
        email = request.POST['email']
        first = request.POST['first_name']
        last = request.POST['last_name']
        password = request.POST['password']
        confirm = request.POST['confirmpassword']
        image = request.FILES.get('image')

        if password != confirm:
            return render(request, 'myapp/register.html', {'error': 'Паролі не співпадають'})

        image_name = None
        if image:
            fs = FileSystemStorage()
            image_name = fs.save(image.name, image)

        CustomUser.objects.create(
            email=email,
            first_name=first,
            last_name=last,
            password=make_password(password),
            image=image_name
        )
        return redirect('login')

    return render(request, 'myapp/register.html')
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from django.contrib.auth.models import User
from rest_framework.serializers import ModelSerializer

class RegisterSerializer(ModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'email', 'password')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user

class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'User created'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class UserView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        return Response({'username': user.username, 'email': user.email})
