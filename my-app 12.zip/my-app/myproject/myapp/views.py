from rest_framework import generics
from .models import Category, Product
from .serializers import ProductSerializer, CategorySerializer

class CategoryListView(generics.ListAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class ProductByCategoryView(generics.ListAPIView):
    serializer_class = ProductSerializer

    def get_queryset(self):
        category_id = self.kwargs['category_id']
        return Product.objects.filter(category_id=category_id)

from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response
from rest_framework import status
from .models import Product, ProductImage
from .serializers import ProductSerializer

class ProductListCreate(APIView):
    parser_classes = [MultiPartParser]

    def get(self, request):
        return Response(ProductSerializer(Product.objects.all(), many=True).data)

    def post(self, request):
        name = request.data.get("name")
        description = request.data.get("description", "")
        price = request.data.get("price", 0)
        images = request.FILES.getlist("images")

        product = Product.objects.create(name=name, description=description, price=price)
        for idx, img in enumerate(images):
            ProductImage.objects.create(product=product, image=img, order=idx)

        return Response(ProductSerializer(product).data, status=status.HTTP_201_CREATED)

class ProductDelete(APIView):
    def delete(self, request, pk):
        product = Product.objects.get(id=pk)
        product.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
