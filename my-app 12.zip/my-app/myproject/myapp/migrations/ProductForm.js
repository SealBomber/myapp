import React, { useState } from 'react';
import axios from 'axios';
import Sortable from 'react-sortablejs';

function ProductForm() {
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [price, setPrice] = useState('');
  const [images, setImages] = useState([]);

  const handleFileChange = (e) => {
    setImages([...images, ...Array.from(e.target.files)]);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData();
    form.append("name", name);
    form.append("description", desc);
    form.append("price", price);
    images.forEach(img => form.append("images", img));
    await axios.post("http://localhost:8000/products/", form);
    alert("Product added!");
  };

  const onSort = (order) => {
    const newOrder = order.map(index => images[parseInt(index)]);
    setImages(newOrder);
  };

  return (
    <form onSubmit={onSubmit}>
      <input placeholder="Назва" onChange={e => setName(e.target.value)} />
      <textarea placeholder="Опис" onChange={e => setDesc(e.target.value)} />
      <input type="number" placeholder="Ціна" onChange={e => setPrice(e.target.value)} />
      <input type="file" multiple onChange={handleFileChange} />
      <Sortable
        tag="div"
        onChange={onSort}
      >
        {images.map((img, idx) => (
          <div key={idx} data-id={idx}>
            <img
              src={URL.createObjectURL(img)}
              alt=""
              width={80}
              style={{ margin: 5 }}
            />
          </div>
        ))}
      </Sortable>
      <button type="submit">Додати товар</button>
    </form>
  );
}

export default ProductForm;

